# Issues Analysis

## Architecture
The bot runs on Amvera with:
- `server.py` → uvicorn → `web:app` → `app.py` (FastAPI)
- `app.py` lifespan → sets webhook OR starts polling thread
- `tg_bot.py` → pyTelegramBotAPI (synchronous) handlers
- Webhook endpoint: `POST /tg/{secret_path}`

## Issues Found

### Issue 1: tg_bot.py creates bot at import time with empty token
Line 24: `bot = telebot.TeleBot(config.TELEGRAM_BOT_TOKEN, parse_mode="HTML")`
- If TELEGRAM_BOT_TOKEN is empty string (default in config.py), pyTelegramBotAPI raises ValueError
- This happens at import time, before config.validate() runs
- FIX: Defer bot creation or handle empty token gracefully

### Issue 2: config.validate() uses sys.exit() instead of raising exception
Line 22: `sys.exit(f"FATAL: Missing required ENV variables: ...")`
- sys.exit() in a lifespan context causes unclean shutdown
- FastAPI shows "Application startup failed" but no clear error in Amvera logs
- FIX: Raise RuntimeError instead

### Issue 3: Webhook processing uses ThreadPoolExecutor
Line 112: `executor.submit(bot.process_new_updates, [update])`
- pyTelegramBotAPI's process_new_updates is synchronous
- Running in thread pool is correct, but if the thread crashes, errors are silently swallowed
- FIX: Add error handling in the executor

### Issue 4: No logging of webhook URL mismatch
Line 104-105: Returns 404 silently if path doesn't match
- If TELEGRAM_WEBHOOK_URL has wrong path, all updates get 404
- FIX: Add debug logging

### Issue 5: Race condition in webhook setup
Line 63: `Thread(target=_configure_webhook, daemon=True).start()`
- Webhook is set in a daemon thread during startup
- If the thread fails, no error is reported to the main thread
- FIX: Add proper error logging

### Issue 6: TELEGRAM_WEBHOOK_URL format
- Must be: `https://domain/tg/secret-path`
- The `/tg/` prefix is hardcoded in the FastAPI route
- If user sets URL without /tg/ prefix, webhook will never match
