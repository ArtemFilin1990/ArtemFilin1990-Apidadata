#!/usr/bin/env python3
"""
Check company by INN via Dadata API.
Usage: python3 check_inn.py <INN> [DADATA_TOKEN]

If DADATA_TOKEN is not provided, reads from env var DADATA_TOKEN or $authorization.
Outputs structured company info to stdout as JSON.
Exit codes: 0 = found, 1 = not found, 2 = error.
"""
import json
import os
import sys
import urllib.request
import urllib.error

DADATA_URL = "https://suggestions.dadata.ru/suggestions/api/4_1/rs/findById/party"


def get_token(argv_token: str | None) -> str:
    if argv_token:
        return argv_token
    for var in ("DADATA_TOKEN", "authorization"):
        val = os.environ.get(var, "").strip()
        if val:
            # Strip "Token " prefix if present
            return val.replace("Token ", "").strip()
    print("Error: No Dadata token. Pass as arg or set DADATA_TOKEN env var.", file=sys.stderr)
    sys.exit(2)


def check_inn(inn: str, token: str) -> dict | None:
    clean = "".join(c for c in inn if c.isdigit())
    if len(clean) not in (10, 12):
        print(f"Error: INN must be 10 or 12 digits, got {len(clean)}", file=sys.stderr)
        sys.exit(2)

    body = json.dumps({"query": clean}).encode()
    req = urllib.request.Request(
        DADATA_URL,
        data=body,
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Token {token}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        print(f"HTTP error: {e.code} {e.reason}", file=sys.stderr)
        sys.exit(2)
    except Exception as e:
        print(f"Request error: {e}", file=sys.stderr)
        sys.exit(2)

    suggestions = data.get("suggestions", [])
    if not suggestions:
        return None
    return suggestions[0]


def format_date(ts: int | None) -> str:
    if not ts:
        return "—"
    from datetime import datetime
    return datetime.fromtimestamp(ts / 1000).strftime("%d.%m.%Y")


def format_money(val: float | None) -> str:
    if val is None:
        return "—"
    return f"{val:,.0f} ₽".replace(",", " ")


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 check_inn.py <INN> [DADATA_TOKEN]", file=sys.stderr)
        sys.exit(2)

    inn = sys.argv[1]
    token = get_token(sys.argv[2] if len(sys.argv) > 2 else None)
    result = check_inn(inn, token)

    if result is None:
        print(f"Not found: INN {inn}", file=sys.stderr)
        sys.exit(1)

    d = result["data"]

    # Print structured summary
    summary = {
        "name_short": d.get("name", {}).get("short_with_opf", result["value"]),
        "name_full": d.get("name", {}).get("full_with_opf", ""),
        "status": d.get("state", {}).get("status", ""),
        "type": d.get("type", ""),
        "inn": d.get("inn", ""),
        "kpp": d.get("kpp", ""),
        "ogrn": d.get("ogrn", ""),
        "okpo": d.get("okpo", ""),
        "oktmo": d.get("oktmo", ""),
        "okato": d.get("okato", ""),
        "address": (d.get("address") or {}).get("unrestricted_value", ""),
        "postal_code": (d.get("address", {}).get("data") or {}).get("postal_code", ""),
        "management_name": (d.get("management") or {}).get("name", ""),
        "management_post": (d.get("management") or {}).get("post", ""),
        "capital": format_money((d.get("capital") or {}).get("value")),
        "okved_main": d.get("okved", ""),
        "registration_date": format_date(d.get("state", {}).get("registration_date")),
        "ogrn_date": format_date(d.get("ogrn_date")),
        "phones": [p["value"] for p in (d.get("phones") or [])],
        "emails": [e["value"] for e in (d.get("emails") or [])],
        "branch_count": d.get("branch_count", 0),
        "employee_count": d.get("employee_count"),
        "okveds": [{"code": o["code"], "name": o["name"], "main": o["main"]} for o in (d.get("okveds") or [])],
    }

    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
