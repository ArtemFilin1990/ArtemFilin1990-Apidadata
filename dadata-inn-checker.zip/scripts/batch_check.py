#!/usr/bin/env python3
"""
Batch check multiple INNs via Dadata API.
Usage: python3 batch_check.py <input_file> <output_file> [DADATA_TOKEN]

Input: text file with one INN per line (or CSV/TSV with INN in first column).
Output: JSON array of results.

Respects Dadata rate limits with 0.2s delay between requests.
"""
import csv
import json
import os
import sys
import time
import urllib.request
import urllib.error

DADATA_URL = "https://suggestions.dadata.ru/suggestions/api/4_1/rs/findById/party"
DELAY = 0.2  # seconds between requests


def get_token(argv_token: str | None) -> str:
    if argv_token:
        return argv_token
    for var in ("DADATA_TOKEN", "authorization"):
        val = os.environ.get(var, "").strip()
        if val:
            return val.replace("Token ", "").strip()
    print("Error: No Dadata token.", file=sys.stderr)
    sys.exit(2)


def fetch_inn(inn: str, token: str) -> dict | None:
    body = json.dumps({"query": inn}).encode()
    req = urllib.request.Request(
        DADATA_URL,
        data=body,
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Token {token}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
    except Exception as e:
        return {"error": str(e), "inn": inn}

    suggestions = data.get("suggestions", [])
    if not suggestions:
        return None
    return suggestions[0]


def extract_summary(result: dict, inn: str) -> dict:
    if result is None:
        return {"inn": inn, "found": False}
    if "error" in result:
        return {"inn": inn, "found": False, "error": result["error"]}

    d = result["data"]
    return {
        "inn": d.get("inn", inn),
        "found": True,
        "name": d.get("name", {}).get("short_with_opf", result.get("value", "")),
        "status": d.get("state", {}).get("status", ""),
        "type": d.get("type", ""),
        "kpp": d.get("kpp", ""),
        "ogrn": d.get("ogrn", ""),
        "address": (d.get("address") or {}).get("value", ""),
        "management": (d.get("management") or {}).get("name", ""),
        "okved": d.get("okved", ""),
    }


def read_inns(filepath: str) -> list[str]:
    inns = []
    with open(filepath, "r", encoding="utf-8") as f:
        # Try CSV first
        sample = f.read(1024)
        f.seek(0)
        if "," in sample or "\t" in sample:
            delimiter = "\t" if "\t" in sample else ","
            reader = csv.reader(f, delimiter=delimiter)
            for row in reader:
                if row:
                    candidate = "".join(c for c in row[0] if c.isdigit())
                    if len(candidate) in (10, 12):
                        inns.append(candidate)
        else:
            for line in f:
                candidate = "".join(c for c in line.strip() if c.isdigit())
                if len(candidate) in (10, 12):
                    inns.append(candidate)
    return inns


def main():
    if len(sys.argv) < 3:
        print("Usage: python3 batch_check.py <input_file> <output_file> [DADATA_TOKEN]", file=sys.stderr)
        sys.exit(2)

    input_file = sys.argv[1]
    output_file = sys.argv[2]
    token = get_token(sys.argv[3] if len(sys.argv) > 3 else None)

    inns = read_inns(input_file)
    if not inns:
        print("No valid INNs found in input file.", file=sys.stderr)
        sys.exit(1)

    print(f"Processing {len(inns)} INNs...", file=sys.stderr)
    results = []

    for i, inn in enumerate(inns):
        result = fetch_inn(inn, token)
        summary = extract_summary(result, inn)
        results.append(summary)
        found = "✓" if summary["found"] else "✗"
        name = summary.get("name", "")
        print(f"  [{i+1}/{len(inns)}] {inn} {found} {name}", file=sys.stderr)
        if i < len(inns) - 1:
            time.sleep(DELAY)

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    found_count = sum(1 for r in results if r["found"])
    print(f"Done: {found_count}/{len(inns)} found. Results → {output_file}", file=sys.stderr)


if __name__ == "__main__":
    main()
