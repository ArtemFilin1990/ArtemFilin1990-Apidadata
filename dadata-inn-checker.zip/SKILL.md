---
name: dadata-inn-checker
description: Check Russian companies and individual entrepreneurs by INN (taxpayer ID) via Dadata API. Returns EGRUL/EGRIP data including requisites, address, management, capital, OKVED, tax authority, contacts. Use when the user asks to verify a counterparty, look up company details by INN, build an INN-checker web app, batch-check multiple INNs, or create a Telegram bot for INN checking. Supports single lookup, batch processing, web UI generation, PDF export, and Telegram bot deployment.
---

# Dadata INN Checker

Verify Russian legal entities and individual entrepreneurs by INN using the Dadata `findById/party` API. Returns structured EGRUL/EGRIP data.

## Prerequisites

- Dadata API token. Check env vars `DADATA_TOKEN` or `authorization`. If missing, ask the user.
- Dadata CORS allows `*`, so browser-side requests work without a proxy.

## Workflow

Determine the task type:

**Single INN lookup (CLI)?** → Run `scripts/check_inn.py`
**Batch INN check?** → Run `scripts/batch_check.py`
**Web UI for INN checking?** → Follow "Web App Workflow" below
**Telegram bot?** → Follow "Telegram Bot Workflow" below

### Single INN Lookup

```bash
python3 /home/ubuntu/skills/dadata-inn-checker/scripts/check_inn.py <INN> [TOKEN]
```

Outputs JSON with: name, status, INN/KPP/OGRN/OKPO/OKTMO/OKATO, address, management, capital, OKVED, phones, emails, branch_count. Exit 0=found, 1=not found, 2=error.

### Batch Check

```bash
python3 /home/ubuntu/skills/dadata-inn-checker/scripts/batch_check.py <input.txt> <output.json> [TOKEN]
```

Input: one INN per line or CSV/TSV with INN in first column. Output: JSON array. Rate-limited at 0.2s/request.

### Web App Workflow

Build a React + Tailwind web app for INN checking:

1. **API integration**: Use Dadata `findById/party` endpoint directly from browser (CORS allowed). See `references/dadata-api.md` for endpoint, headers, request/response format, and TypeScript interface.

2. **Core components to implement**:
   - Search box with INN validation (10 digits = юр. лицо, 12 = ИП)
   - Result card grid with sections: Реквизиты, Адрес, Руководитель, Финансы/даты, ОКВЭД, Налоговая, Контакты, Филиалы
   - Status badge with color coding (ACTIVE=green, LIQUIDATING/REORGANIZING=yellow, LIQUIDATED/BANKRUPT=red)
   - Copy-to-clipboard for each requisite field
   - PDF export via `jspdf` (install: `pnpm add jspdf`)

3. **Data display rules**:
   - Timestamps from API are milliseconds → convert with `new Date(timestamp)`
   - Capital format: Russian rubles with `Intl.NumberFormat("ru-RU", { style: "currency", currency: "RUB" })`
   - Company age: calculate from `state.registration_date` to now
   - Monospace font for INN/KPP/OGRN/OKPO values (e.g., JetBrains Mono)
   - Show all OKVEDs, mark `main: true` as "(основной)"

4. **PDF export**: Use `jspdf` with cyrillic font (PTSans from fontsource CDN). Structure: indigo header bar → company name + status → sections (Реквизиты, Адрес, Руководитель, Финансы, ОКВЭД, Налоговая, Контакты) → footer with page numbers.

5. **INN validation**: Strip non-digits, accept only 10 or 12 digit strings. Show hint: "Введите 10 цифр для юр. лица или 12 для ИП".

### Telegram Bot Workflow

Build a Telegram bot for INN checking using `python-telegram-bot`:

1. **Prerequisites**: Ask user for bot token from @BotFather. Install: `pip install python-telegram-bot`.

2. **Template**: Copy `templates/telegram_bot.py` to the project directory. Replace `BOT_TOKEN` and `DADATA_TOKEN` with actual values (env vars or hardcoded).

3. **Bot features** (implemented in template):
   - `/start` — welcome message + ReplyKeyboard with "🔍 Проверить ИНН" and "ℹ️ Справка" buttons
   - `/check <INN>` — check by command
   - `/help` — usage instructions
   - Plain text INN (10/12 digits) — auto-detected and checked
   - Formatted HTML output: name, status (✅/⚠️/❌), requisites in `<code>` tags (tap to copy), address, management, capital, OKVED (top 5), tax authority, contacts
   - InlineKeyboard: "📍 На карте" (Yandex Maps link from geocoords), "🔄 Новый запрос"
   - Long message splitting (>4000 chars)

4. **Run**: `python3 bot.py` (polling mode). For production: systemd service or Docker.

5. **Customization points**:
   - Add `/start` restrictions (whitelist user IDs) for private bots
   - Add inline mode for checking INN from any chat
   - Add PDF generation and send as document attachment

## API Reference

For full endpoint docs, TypeScript interface, field descriptions, and status/type mappings, read `references/dadata-api.md`.

## Key Gotchas

- Token goes in `Authorization: Token <token>` header (not Bearer).
- `management` is `null` for ИП — handle gracefully.
- `phones` and `emails` are `null` (not empty array) when absent.
- `capital` is `null` for ИП.
- `state.liquidation_date` is `null` for active companies.
- `branch_count` can be 0 — hide section if so.
- OKVED codes in `okveds[]` array; `okved` field is just the main code string.
